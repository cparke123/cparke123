#!/bin/bash
# ─── ClipRadar Quick Start ─────────────────────────────────────
# Run this script to set up ClipRadar for the first time.

set -e

echo ""
echo "⚡ ClipRadar — Quick Start"
echo "──────────────────────────"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Install from https://python.org"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✓ Python $PYTHON_VERSION found"

# Check FFmpeg
if ! command -v ffmpeg &> /dev/null; then
    echo "❌ FFmpeg is required."
    echo "  macOS:   brew install ffmpeg"
    echo "  Ubuntu:  sudo apt install ffmpeg"
    echo "  Windows: choco install ffmpeg"
    exit 1
fi
echo "✓ FFmpeg found"

# Create virtual environment
if [ ! -d "venv" ]; then
    echo ""
    echo "Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate
echo "✓ Virtual environment activated"

# Install dependencies
echo ""
echo "Installing dependencies..."
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo "✓ Dependencies installed"

# Set up config
if [ ! -f "config/.env" ]; then
    cp config/.env.example config/.env
    echo ""
    echo "⚠  Created config/.env — you need to add your API keys!"
    echo "   Required: SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET"
    echo "   Required: REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET"
    echo ""
    echo "   Get Spotify keys: https://developer.spotify.com/dashboard"
    echo "   Get Reddit keys:  https://www.reddit.com/prefs/apps"
    echo ""
fi

# Create data directories
mkdir -p data/audio data/clips data/transcripts
echo "✓ Data directories created"

# Initialize database
echo ""
python scripts/init_db.py

echo ""
echo "─────────────────────────────────────────────"
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Add your API keys to config/.env"
echo "  2. Run the pipeline:"
echo "     python -m backend.pipeline --full"
echo ""
echo "  Or run individual stages:"
echo "     python -m backend.pipeline --stage 1  # Ingest"
echo "     python -m backend.pipeline --stage 2  # Signal Scan"
echo "     python -m backend.pipeline --stage 3  # Transcribe"
echo "     python -m backend.pipeline --stage 4  # Detect"
echo "     python -m backend.pipeline --stage 5  # Clip"
echo "─────────────────────────────────────────────"
echo ""
