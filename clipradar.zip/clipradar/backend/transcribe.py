"""
Stage 3: Transcription + Audio Analysis
────────────────────────────────────────
Transcribes episodes with word-level timestamps using faster-whisper,
and analyzes audio for energy spikes, laughter, and crowd reactions.
"""

import json
import subprocess
from pathlib import Path
from typing import Optional

import numpy as np
from loguru import logger
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from backend.config import settings
from backend.models import Episode, init_db

console = Console()


class WhisperTranscriber:
    """Transcribes podcast audio using faster-whisper (local, no API key)."""

    def __init__(self, model_size: str = "base"):
        """
        Initialize transcriber.

        Args:
            model_size: Whisper model size. Options:
                - "tiny"    — Fastest, least accurate (~1GB RAM)
                - "base"    — Good balance for dev (~1GB RAM)
                - "small"   — Better accuracy (~2GB RAM)
                - "medium"  — High accuracy (~5GB RAM)
                - "large-v3" — Best accuracy (~10GB RAM, needs GPU)
        """
        self.model_size = model_size
        self.model = None

    def _load_model(self):
        """Lazy-load the Whisper model."""
        if self.model is not None:
            return

        try:
            from faster_whisper import WhisperModel

            # Use CPU by default; set device="cuda" if you have a GPU
            self.model = WhisperModel(
                self.model_size,
                device="cpu",
                compute_type="int8",  # Quantized for speed on CPU
            )
            logger.info(f"Loaded faster-whisper model: {self.model_size}")

        except ImportError:
            logger.error(
                "faster-whisper not installed. Install with: "
                "pip install faster-whisper"
            )
            raise

    def transcribe(
        self,
        audio_path: str | Path,
        language: str = "en",
    ) -> dict:
        """
        Transcribe an audio file with word-level timestamps.

        Returns:
            {
                "segments": [
                    {
                        "start": float,     # seconds
                        "end": float,
                        "text": str,
                        "words": [
                            {"start": float, "end": float, "word": str, "probability": float}
                        ],
                        "avg_logprob": float,
                    }
                ],
                "language": str,
                "duration": float,
            }
        """
        self._load_model()
        audio_path = Path(audio_path)

        if not audio_path.exists():
            raise FileNotFoundError(f"Audio file not found: {audio_path}")

        logger.info(f"Transcribing: {audio_path.name}")

        segments_raw, info = self.model.transcribe(
            str(audio_path),
            language=language,
            word_timestamps=True,
            vad_filter=True,  # Filter out silence
            vad_parameters=dict(min_silence_duration_ms=500),
        )

        segments = []
        for seg in segments_raw:
            words = []
            if seg.words:
                for w in seg.words:
                    words.append({
                        "start": round(w.start, 3),
                        "end": round(w.end, 3),
                        "word": w.word,
                        "probability": round(w.probability, 3),
                    })

            segments.append({
                "start": round(seg.start, 3),
                "end": round(seg.end, 3),
                "text": seg.text.strip(),
                "words": words,
                "avg_logprob": round(seg.avg_logprob, 3),
            })

        result = {
            "segments": segments,
            "language": info.language,
            "duration": info.duration,
            "model": self.model_size,
        }

        logger.success(
            f"Transcribed {len(segments)} segments, "
            f"duration: {info.duration:.0f}s"
        )
        return result

    def save_transcript(self, transcript: dict, output_path: str | Path):
        """Save transcript to JSON file."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(transcript, f, indent=2)
        logger.info(f"Saved transcript: {output_path}")


class AudioAnalyzer:
    """Analyzes audio for energy spikes, laughter, and crowd reactions."""

    @staticmethod
    def analyze_energy(audio_path: str | Path, hop_length: int = 512) -> dict:
        """
        Analyze audio energy over time to detect spikes.

        Returns energy profile with timestamps of peaks.
        """
        try:
            import librosa

            y, sr = librosa.load(str(audio_path), sr=22050, mono=True)
            duration = len(y) / sr

            # RMS energy over time
            rms = librosa.feature.rms(y=y, hop_length=hop_length)[0]
            times = librosa.frames_to_time(
                np.arange(len(rms)), sr=sr, hop_length=hop_length
            )

            # Normalize to 0-1
            rms_norm = (rms - rms.min()) / (rms.max() - rms.min() + 1e-8)

            # Detect energy spikes (peaks above mean + 1.5 std)
            threshold = np.mean(rms_norm) + 1.5 * np.std(rms_norm)
            spike_indices = np.where(rms_norm > threshold)[0]

            # Cluster nearby spikes into moments
            spikes = []
            if len(spike_indices) > 0:
                clusters = _cluster_indices(spike_indices, gap=20)  # ~0.5s gap
                for cluster in clusters:
                    start_time = float(times[cluster[0]])
                    end_time = float(times[cluster[-1]])
                    peak_energy = float(np.max(rms_norm[cluster]))
                    spikes.append({
                        "start": round(start_time, 2),
                        "end": round(end_time, 2),
                        "duration": round(end_time - start_time, 2),
                        "peak_energy": round(peak_energy, 3),
                    })

            logger.info(f"Found {len(spikes)} energy spikes in {duration:.0f}s audio")

            return {
                "duration": duration,
                "sample_rate": sr,
                "mean_energy": float(np.mean(rms_norm)),
                "spike_count": len(spikes),
                "spikes": sorted(spikes, key=lambda s: s["peak_energy"], reverse=True),
            }

        except ImportError:
            logger.warning("librosa not installed — skipping energy analysis")
            return {"duration": 0, "spikes": [], "spike_count": 0}

    @staticmethod
    def detect_laughter_regions(
        audio_path: str | Path,
        window_sec: float = 5.0,
        energy_threshold: float = 0.6,
    ) -> list[dict]:
        """
        Detect likely laughter/crowd reaction regions using spectral features.

        Laughter tends to have:
        - High spectral centroid (bright sound)
        - High spectral bandwidth (wide frequency range)
        - Rapid energy fluctuations (ha-ha-ha pattern)

        This is a heuristic approach. For production, consider a dedicated
        laughter detection model (e.g., https://github.com/jrgillick/laughter-detection).
        """
        try:
            import librosa

            y, sr = librosa.load(str(audio_path), sr=22050, mono=True)

            # Compute features in windows
            hop = 512
            centroid = librosa.feature.spectral_centroid(y=y, sr=sr, hop_length=hop)[0]
            bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr, hop_length=hop)[0]
            rms = librosa.feature.rms(y=y, hop_length=hop)[0]
            zcr = librosa.feature.zero_crossing_rate(y, hop_length=hop)[0]

            times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop)

            # Normalize features
            centroid_norm = (centroid - centroid.min()) / (centroid.max() - centroid.min() + 1e-8)
            bandwidth_norm = (bandwidth - bandwidth.min()) / (bandwidth.max() - bandwidth.min() + 1e-8)
            rms_norm = (rms - rms.min()) / (rms.max() - rms.min() + 1e-8)
            zcr_norm = (zcr - zcr.min()) / (zcr.max() - zcr.min() + 1e-8)

            # Composite "laughter likelihood" score
            # Laughter = high energy + high centroid + high ZCR + moderate bandwidth
            laughter_score = (
                rms_norm * 0.3 +
                centroid_norm * 0.25 +
                zcr_norm * 0.25 +
                bandwidth_norm * 0.2
            )

            # Find regions above threshold
            threshold = np.percentile(laughter_score, 90)  # Top 10% energy
            laugh_indices = np.where(laughter_score > threshold)[0]

            if len(laugh_indices) == 0:
                return []

            clusters = _cluster_indices(laugh_indices, gap=40)  # ~1s gap
            regions = []
            for cluster in clusters:
                start = float(times[cluster[0]])
                end = float(times[cluster[-1]])
                if end - start >= 1.0:  # At least 1 second
                    regions.append({
                        "start": round(start, 2),
                        "end": round(end, 2),
                        "duration": round(end - start, 2),
                        "intensity": round(float(np.mean(laughter_score[cluster])), 3),
                    })

            logger.info(f"Detected {len(regions)} likely laughter regions")
            return sorted(regions, key=lambda r: r["intensity"], reverse=True)

        except ImportError:
            logger.warning("librosa not installed — skipping laughter detection")
            return []


def _cluster_indices(indices: np.ndarray, gap: int = 10) -> list[list[int]]:
    """Cluster consecutive-ish indices into groups."""
    if len(indices) == 0:
        return []

    clusters = [[indices[0]]]
    for idx in indices[1:]:
        if idx - clusters[-1][-1] <= gap:
            clusters[-1].append(idx)
        else:
            clusters.append([idx])

    return [c for c in clusters if len(c) >= 3]  # At least 3 frames


async def run_transcribe():
    """Main transcription pipeline."""
    console.print("\n[bold cyan]═══ CLIPRADAR: STAGE 3 — TRANSCRIBE ═══[/bold cyan]\n")

    engine, Session = init_db()
    session = Session()

    # Get episodes with downloaded audio that haven't been transcribed
    episodes = (
        session.query(Episode)
        .filter(
            Episode.local_audio_path.isnot(None),
            Episode.transcribed == False,
        )
        .limit(5)
        .all()
    )

    if not episodes:
        console.print("[yellow]No episodes ready for transcription.[/yellow]")
        console.print("Run the ingest + download stage first.")
        return

    transcriber = WhisperTranscriber(model_size="base")
    analyzer = AudioAnalyzer()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
    ) as progress:

        for episode in episodes:
            audio_path = Path(episode.local_audio_path)

            if not audio_path.exists():
                logger.warning(f"Audio not found: {audio_path}")
                continue

            task = progress.add_task(
                f"Transcribing: {episode.title[:50]}...",
                total=100,
            )

            # Step 1: Transcribe (60% of work)
            progress.update(task, advance=10, description="Loading model...")
            transcript = transcriber.transcribe(audio_path)
            progress.update(task, advance=50)

            # Save transcript
            safe_title = episode.title[:60].replace(" ", "_").replace("/", "_")
            transcript_path = settings.transcripts_dir / f"{episode.id}__{safe_title}.json"
            transcriber.save_transcript(transcript, transcript_path)

            # Step 2: Audio energy analysis (20%)
            progress.update(task, description="Analyzing audio energy...")
            energy = analyzer.analyze_energy(audio_path)
            progress.update(task, advance=20)

            # Step 3: Laughter detection (20%)
            progress.update(task, description="Detecting laughter regions...")
            laughter = analyzer.detect_laughter_regions(audio_path)
            progress.update(task, advance=20)

            # Save analysis alongside transcript
            analysis = {
                "transcript": transcript,
                "energy_analysis": energy,
                "laughter_regions": laughter,
            }
            analysis_path = settings.transcripts_dir / f"{episode.id}__analysis.json"
            with open(analysis_path, "w") as f:
                json.dump(analysis, f, indent=2)

            # Update DB
            episode.transcribed = True
            episode.transcript_path = str(transcript_path)
            session.commit()

            progress.update(task, completed=100, description=f"✓ {episode.title[:50]}")

    console.print("\n[bold green]Transcription complete.[/bold green]\n")
    session.close()


if __name__ == "__main__":
    import asyncio
    asyncio.run(run_transcribe())
