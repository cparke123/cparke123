"""ClipRadar configuration management."""

from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from environment / .env file."""

    # ─── Spotify ─────────────────────────────────────────
    spotify_client_id: str = ""
    spotify_client_secret: str = ""

    # ─── Reddit ──────────────────────────────────────────
    reddit_client_id: str = ""
    reddit_client_secret: str = ""
    reddit_user_agent: str = "ClipRadar/1.0"

    # ─── Optional APIs ───────────────────────────────────
    openai_api_key: str = ""
    youtube_api_key: str = ""
    twitter_bearer_token: str = ""
    huggingface_token: str = ""

    # ─── Database ────────────────────────────────────────
    database_url: str = "sqlite+aiosqlite:///./clipradar.db"
    redis_url: str = "redis://localhost:6379/0"

    # ─── Paths ───────────────────────────────────────────
    audio_dir: Path = Path("./data/audio")
    clips_dir: Path = Path("./data/clips")
    transcripts_dir: Path = Path("./data/transcripts")

    # ─── Clip Defaults ───────────────────────────────────
    clip_duration_sec: int = 30
    clip_format: str = "mp4"
    clip_resolution: str = "1080x1920"
    caption_style: str = "bold_centered"

    model_config = {
        "env_file": "config/.env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    def ensure_dirs(self):
        """Create data directories if they don't exist."""
        for d in [self.audio_dir, self.clips_dir, self.transcripts_dir]:
            d.mkdir(parents=True, exist_ok=True)


# Singleton
settings = Settings()
settings.ensure_dirs()
