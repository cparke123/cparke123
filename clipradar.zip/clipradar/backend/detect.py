"""
Stage 4: Viral Moment Detection
────────────────────────────────
Combines social signals, audio energy, laughter detection, and
transcript patterns to score and rank the most clip-worthy moments.
"""

import json
import re
from pathlib import Path
from typing import Optional

import numpy as np
from loguru import logger
from rich.console import Console
from rich.table import Table

from backend.config import settings
from backend.models import Episode, ViralMoment, SocialSignal, init_db

console = Console()

# ─── Scoring Weights ────────────────────────────────────────────
WEIGHTS = {
    "social_signal": 0.30,   # Social heat from Reddit/YouTube/Twitter
    "audio_energy": 0.20,    # Raw audio energy spikes
    "laughter": 0.25,        # Laughter/crowd reaction detection
    "transcript": 0.15,      # Punchline patterns, keyword density
    "timestamp_refs": 0.10,  # Direct timestamp references from social
}


class MomentDetector:
    """Composite scoring engine for viral moment detection."""

    def __init__(self, clip_duration_sec: int = 30):
        self.clip_duration = clip_duration_sec

    def detect_moments(
        self,
        episode_id: int,
        transcript: dict,
        energy_analysis: dict,
        laughter_regions: list[dict],
        social_signals: list[dict],
        max_moments: int = 10,
    ) -> list[dict]:
        """
        Detect and score viral moments in an episode.

        Combines all signal sources into a unified scoring system.
        Returns top N moments ranked by composite viral score.
        """
        # Step 1: Generate candidate windows across the episode
        duration = transcript.get("duration", 0)
        if duration == 0:
            return []

        candidates = self._generate_candidate_windows(
            duration, self.clip_duration
        )

        # Step 2: Score each candidate window
        scored = []
        for window in candidates:
            start = window["start"]
            end = window["end"]

            scores = {
                "social": self._score_social(start, end, social_signals),
                "energy": self._score_energy(start, end, energy_analysis),
                "laughter": self._score_laughter(start, end, laughter_regions),
                "transcript": self._score_transcript(start, end, transcript),
                "timestamp_refs": self._score_timestamp_refs(start, end, social_signals),
            }

            # Composite score
            composite = (
                scores["social"] * WEIGHTS["social_signal"] +
                scores["energy"] * WEIGHTS["audio_energy"] +
                scores["laughter"] * WEIGHTS["laughter"] +
                scores["transcript"] * WEIGHTS["transcript"] +
                scores["timestamp_refs"] * WEIGHTS["timestamp_refs"]
            )

            # Extract the transcript snippet for this window
            snippet = self._get_transcript_snippet(start, end, transcript)
            label = self._generate_label(scores, snippet)
            tags = self._generate_tags(scores, snippet)

            scored.append({
                "episode_id": episode_id,
                "start_ms": int(start * 1000),
                "end_ms": int(end * 1000),
                "duration_ms": int(self.clip_duration * 1000),
                "viral_score": round(composite * 100, 1),
                "social_score": round(scores["social"] * 100, 1),
                "audio_energy_score": round(scores["energy"] * 100, 1),
                "laughter_score": round(scores["laughter"] * 100, 1),
                "transcript_score": round(scores["transcript"] * 100, 1),
                "label": label,
                "transcript_snippet": snippet,
                "tags": tags,
            })

        # Step 3: Sort by score, remove overlapping windows, take top N
        scored.sort(key=lambda x: x["viral_score"], reverse=True)
        filtered = self._remove_overlapping(scored)
        return filtered[:max_moments]

    def _generate_candidate_windows(
        self, duration: float, window_sec: int
    ) -> list[dict]:
        """Generate overlapping candidate windows across the episode."""
        step = window_sec // 2  # 50% overlap (15s steps for 30s windows)
        windows = []
        start = 30  # Skip first 30s (usually intro/ads)
        end_boundary = duration - 60  # Skip last 60s (usually outro)

        while start + window_sec <= end_boundary:
            windows.append({
                "start": start,
                "end": start + window_sec,
            })
            start += step

        return windows

    def _score_social(
        self, start: float, end: float, signals: list[dict]
    ) -> float:
        """Score window based on social signal density near this timestamp."""
        if not signals:
            return 0.0

        score = 0.0
        for sig in signals:
            ts_ref = sig.get("timestamp_ref")
            if ts_ref:
                # Convert timestamp string to seconds
                ref_sec = _timestamp_to_seconds(ts_ref)
                if ref_sec is not None:
                    # Check if reference is within or near this window
                    distance = min(abs(ref_sec - start), abs(ref_sec - end))
                    if distance <= 60:  # Within 60s of window
                        proximity_bonus = max(0, 1 - distance / 60)
                        engagement = sig.get("engagement", 0)
                        score += proximity_bonus * min(1.0, engagement / 500)

            # General engagement adds baseline signal
            score += sig.get("viral_keywords", 0) * 0.02

        return min(1.0, score)

    def _score_energy(
        self, start: float, end: float, energy: dict
    ) -> float:
        """Score window based on audio energy spikes."""
        spikes = energy.get("spikes", [])
        if not spikes:
            return 0.0

        score = 0.0
        for spike in spikes:
            # Check if spike overlaps with this window
            spike_start = spike["start"]
            spike_end = spike["end"]

            overlap = max(0, min(end, spike_end) - max(start, spike_start))
            if overlap > 0:
                score += spike["peak_energy"] * (overlap / (end - start))

        return min(1.0, score)

    def _score_laughter(
        self, start: float, end: float, laughter: list[dict]
    ) -> float:
        """Score window based on laughter/crowd reaction detection."""
        if not laughter:
            return 0.0

        score = 0.0
        for region in laughter:
            # Check overlap
            overlap = max(0, min(end, region["end"]) - max(start, region["start"]))
            if overlap > 0:
                score += region["intensity"] * (overlap / (end - start))

        return min(1.0, score)

    def _score_transcript(
        self, start: float, end: float, transcript: dict
    ) -> float:
        """Score window based on transcript content patterns."""
        segments = transcript.get("segments", [])
        window_text = ""
        word_count = 0

        for seg in segments:
            if seg["end"] >= start and seg["start"] <= end:
                window_text += " " + seg["text"]
                word_count += len(seg["text"].split())

        if not window_text.strip():
            return 0.0

        text_lower = window_text.lower()
        score = 0.0

        # Pattern: rapid speech (high word density = excited delivery)
        words_per_sec = word_count / max(end - start, 1)
        if words_per_sec > 3.5:  # Fast talking
            score += 0.2

        # Pattern: explicit/emphasis words (comedy-specific)
        comedy_markers = [
            "fuck", "shit", "holy", "oh my god", "wait what",
            "no way", "are you serious", "that's insane", "bro",
            "dude", "literally", "i can't", "stop",
        ]
        marker_count = sum(1 for m in comedy_markers if m in text_lower)
        score += min(0.3, marker_count * 0.05)

        # Pattern: question-answer flow (setup → punchline)
        if "?" in window_text and text_lower.count("?") <= 3:
            score += 0.15

        # Pattern: short bursts (indicates crosstalk/reactions)
        short_segments = sum(
            1 for seg in segments
            if seg["end"] >= start and seg["start"] <= end
            and len(seg["text"].split()) <= 5
        )
        if short_segments >= 3:
            score += 0.15

        # Pattern: exclamations
        exclamation_count = window_text.count("!")
        score += min(0.2, exclamation_count * 0.04)

        return min(1.0, score)

    def _score_timestamp_refs(
        self, start: float, end: float, signals: list[dict]
    ) -> float:
        """Score based on how many social posts directly reference this timestamp."""
        ref_count = 0
        for sig in signals:
            ts_ref = sig.get("timestamp_ref")
            if ts_ref:
                ref_sec = _timestamp_to_seconds(ts_ref)
                if ref_sec and start <= ref_sec <= end:
                    ref_count += 1

        # 3+ direct references = max score
        return min(1.0, ref_count / 3)

    def _get_transcript_snippet(
        self, start: float, end: float, transcript: dict
    ) -> str:
        """Extract transcript text for a time window."""
        segments = transcript.get("segments", [])
        texts = []
        for seg in segments:
            if seg["end"] >= start and seg["start"] <= end:
                texts.append(seg["text"])
        return " ".join(texts).strip()[:300]

    def _generate_label(self, scores: dict, snippet: str) -> str:
        """Generate a human-readable label for a moment."""
        top_signal = max(scores, key=scores.get)
        labels = {
            "laughter": "Crowd/laughter peak moment",
            "energy": "High-energy moment",
            "social": "Socially viral segment",
            "transcript": "Sharp comedy delivery",
            "timestamp_refs": "Fan-flagged highlight",
        }

        base = labels.get(top_signal, "Notable moment")

        # Add context from snippet if possible
        if snippet:
            first_words = snippet[:60].strip()
            if first_words:
                base += f' — "{first_words}..."'

        return base

    def _generate_tags(self, scores: dict, snippet: str) -> list[str]:
        """Generate tags for a moment based on its characteristics."""
        tags = []
        if scores["laughter"] > 0.5:
            tags.append("laughter")
        if scores["energy"] > 0.6:
            tags.append("high_energy")
        if scores["social"] > 0.4:
            tags.append("trending")
        if scores["timestamp_refs"] > 0.3:
            tags.append("fan_favorite")

        snippet_lower = snippet.lower()
        if any(w in snippet_lower for w in ["roast", "burn", "destroyed"]):
            tags.append("roast")
        if "?" in snippet:
            tags.append("crowd_work")

        return tags or ["highlight"]

    def _remove_overlapping(self, moments: list[dict], min_gap_ms: int = 15000) -> list[dict]:
        """Remove overlapping moments, keeping higher-scored ones."""
        if not moments:
            return []

        filtered = [moments[0]]
        for moment in moments[1:]:
            overlaps = False
            for kept in filtered:
                if (abs(moment["start_ms"] - kept["start_ms"]) < min_gap_ms):
                    overlaps = True
                    break
            if not overlaps:
                filtered.append(moment)

        return filtered


def _timestamp_to_seconds(ts: str) -> Optional[float]:
    """Convert timestamp string to seconds."""
    try:
        if ":" in ts:
            parts = ts.split(":")
            if len(parts) == 3:
                h, m, s = parts
                return int(h) * 3600 + int(m) * 60 + float(s)
            elif len(parts) == 2:
                m, s = parts
                return int(m) * 60 + float(s)
        else:
            return float(ts) * 60  # Assume minutes
    except (ValueError, TypeError):
        return None


async def run_detect():
    """Main viral moment detection pipeline."""
    console.print("\n[bold cyan]═══ CLIPRADAR: STAGE 4 — DETECT MOMENTS ═══[/bold cyan]\n")

    engine, Session = init_db()
    session = Session()

    # Get transcribed episodes that haven't been processed
    episodes = (
        session.query(Episode)
        .filter(
            Episode.transcribed == True,
            Episode.processed == False,
        )
        .limit(10)
        .all()
    )

    if not episodes:
        console.print("[yellow]No transcribed episodes ready for detection.[/yellow]")
        return

    detector = MomentDetector(clip_duration_sec=settings.clip_duration_sec)

    for episode in episodes:
        console.print(f"\n[bold]Processing: {episode.title}[/bold]")

        # Load transcript + analysis
        analysis_path = settings.transcripts_dir / f"{episode.id}__analysis.json"
        if not analysis_path.exists():
            logger.warning(f"Analysis file not found: {analysis_path}")
            continue

        with open(analysis_path) as f:
            analysis = json.load(f)

        # Get social signals from DB
        db_signals = (
            session.query(SocialSignal)
            .filter_by(episode_id=episode.id)
            .all()
        )
        social_signals = [
            {
                "platform": s.platform,
                "signal_type": s.signal_type,
                "engagement": s.engagement,
                "timestamp_ref": s.timestamp_ref,
                "viral_keywords": 0,  # Already processed
            }
            for s in db_signals
        ]

        # Run detection
        moments = detector.detect_moments(
            episode_id=episode.id,
            transcript=analysis.get("transcript", {}),
            energy_analysis=analysis.get("energy_analysis", {}),
            laughter_regions=analysis.get("laughter_regions", []),
            social_signals=social_signals,
        )

        # Store moments in DB
        table = Table(title=f"Viral Moments: {episode.title[:50]}")
        table.add_column("#", style="dim", width=3)
        table.add_column("Score", justify="center", style="bold")
        table.add_column("Timestamp", justify="center")
        table.add_column("Label", max_width=50)
        table.add_column("Tags")

        for i, moment in enumerate(moments):
            db_moment = ViralMoment(
                episode_id=episode.id,
                timestamp_start_ms=moment["start_ms"],
                timestamp_end_ms=moment["end_ms"],
                duration_ms=moment["duration_ms"],
                viral_score=moment["viral_score"],
                social_score=moment["social_score"],
                audio_energy_score=moment["audio_energy_score"],
                laughter_score=moment["laughter_score"],
                transcript_score=moment["transcript_score"],
                label=moment["label"],
                transcript_snippet=moment["transcript_snippet"],
                tags=moment["tags"],
            )
            session.add(db_moment)

            # Format for display
            start_sec = moment["start_ms"] / 1000
            mins, secs = divmod(int(start_sec), 60)
            hours, mins = divmod(mins, 60)
            ts_str = f"{hours}:{mins:02d}:{secs:02d}"

            score_color = (
                "green" if moment["viral_score"] >= 70
                else "yellow" if moment["viral_score"] >= 50
                else "dim"
            )

            table.add_row(
                str(i + 1),
                f"[{score_color}]{moment['viral_score']:.0f}[/{score_color}]",
                ts_str,
                moment["label"][:48],
                ", ".join(moment["tags"]),
            )

        episode.processed = True
        session.commit()
        console.print(table)

    console.print("\n[bold green]Moment detection complete.[/bold green]\n")
    session.close()


if __name__ == "__main__":
    import asyncio
    asyncio.run(run_detect())
