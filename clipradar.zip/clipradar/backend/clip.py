"""
Stage 5: Clip Generation
─────────────────────────
Extracts 30-second audio segments, generates captions from
word-level timestamps, and renders 9:16 vertical video
formatted for YouTube Shorts and TikTok.
"""

import json
import subprocess
import shutil
from pathlib import Path
from typing import Optional

from loguru import logger
from rich.console import Console
from rich.table import Table

from backend.config import settings
from backend.models import Episode, ViralMoment, GeneratedClip, init_db

console = Console()


class ClipGenerator:
    """Generates short-form video clips from podcast audio moments."""

    def __init__(self):
        # Verify FFmpeg is installed
        if not shutil.which("ffmpeg"):
            raise RuntimeError(
                "FFmpeg is required but not found. Install with:\n"
                "  macOS:  brew install ffmpeg\n"
                "  Ubuntu: sudo apt install ffmpeg\n"
                "  Windows: choco install ffmpeg"
            )

    def extract_audio_clip(
        self,
        audio_path: str | Path,
        start_ms: int,
        duration_ms: int,
        output_path: str | Path,
    ) -> Path:
        """Extract a segment of audio from the full episode."""
        audio_path = Path(audio_path)
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        start_sec = start_ms / 1000
        duration_sec = duration_ms / 1000

        cmd = [
            "ffmpeg", "-y",
            "-i", str(audio_path),
            "-ss", str(start_sec),
            "-t", str(duration_sec),
            "-acodec", "libmp3lame",
            "-ab", "128k",
            str(output_path),
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            logger.error(f"FFmpeg audio extraction failed: {result.stderr}")
            raise RuntimeError(f"Audio extraction failed: {result.stderr}")

        logger.info(f"Extracted audio clip: {output_path}")
        return output_path

    def generate_srt_captions(
        self,
        transcript: dict,
        start_ms: int,
        end_ms: int,
        output_path: str | Path,
        max_words_per_line: int = 6,
    ) -> Path:
        """
        Generate SRT caption file from word-level timestamps.
        Captions are chunked into short phrases for readability.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        start_sec = start_ms / 1000
        end_sec = end_ms / 1000

        # Collect words within the clip window
        words = []
        for segment in transcript.get("segments", []):
            if segment["end"] < start_sec or segment["start"] > end_sec:
                continue
            for word in segment.get("words", []):
                if start_sec <= word["start"] <= end_sec:
                    words.append({
                        "word": word["word"],
                        "start": word["start"] - start_sec,  # Offset to clip start
                        "end": word["end"] - start_sec,
                    })

        if not words:
            # Fallback: use segment-level text
            for segment in transcript.get("segments", []):
                if segment["end"] >= start_sec and segment["start"] <= end_sec:
                    adj_start = max(0, segment["start"] - start_sec)
                    adj_end = min(end_sec - start_sec, segment["end"] - start_sec)
                    words.append({
                        "word": segment["text"],
                        "start": adj_start,
                        "end": adj_end,
                    })

        # Group words into caption chunks
        chunks = []
        current_chunk = []
        for word in words:
            current_chunk.append(word)
            if len(current_chunk) >= max_words_per_line:
                chunks.append(current_chunk)
                current_chunk = []
        if current_chunk:
            chunks.append(current_chunk)

        # Write SRT file
        srt_lines = []
        for i, chunk in enumerate(chunks, 1):
            start_time = _format_srt_time(chunk[0]["start"])
            end_time = _format_srt_time(chunk[-1]["end"])
            text = " ".join(w["word"].strip() for w in chunk)

            srt_lines.append(f"{i}")
            srt_lines.append(f"{start_time} --> {end_time}")
            srt_lines.append(text.upper())  # Uppercase for Shorts/TikTok style
            srt_lines.append("")

        output_path.write_text("\n".join(srt_lines))
        logger.info(f"Generated {len(chunks)} caption chunks: {output_path}")
        return output_path

    def render_clip_video(
        self,
        audio_clip_path: str | Path,
        srt_path: str | Path,
        output_path: str | Path,
        podcast_name: str = "",
        episode_title: str = "",
        format_preset: str = "shorts",
    ) -> Path:
        """
        Render a 9:16 vertical video with audio, captions, and branding.

        Creates a video with:
        - Black background (or gradient)
        - Animated waveform visualization
        - Burned-in captions (bold, centered)
        - Podcast name + episode title overlay
        """
        audio_clip_path = Path(audio_clip_path)
        srt_path = Path(srt_path)
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Resolution settings
        width, height = 1080, 1920

        # Caption styling — bold centered white text, TikTok/Shorts style
        caption_style = (
            "FontName=Arial Black,"
            "FontSize=22,"
            "PrimaryColour=&H00FFFFFF,"      # White text
            "OutlineColour=&H00000000,"       # Black outline
            "BackColour=&H80000000,"          # Semi-transparent background
            "Bold=1,"
            "Outline=2,"
            "Shadow=1,"
            "MarginV=120,"                    # Position from bottom
            "Alignment=2"                      # Center aligned
        )

        # Build FFmpeg filter complex
        # 1. Create gradient background
        # 2. Overlay audio waveform visualization
        # 3. Burn in captions
        # 4. Add text overlays (podcast name, etc.)

        filter_parts = [
            # Dark gradient background
            f"color=c=0x0a0a14:s={width}x{height}:d=30[bg]",

            # Audio waveform visualization (centered)
            f"[0:a]showwaves=s={width}x200:mode=cline:rate=30:"
            f"colors=0xff3366|0x00e5ff:scale=sqrt[wave]",

            # Position waveform in center of frame
            f"[bg][wave]overlay=(W-w)/2:(H-h)/2:shortest=1[v1]",
        ]

        # Add podcast name text at top
        if podcast_name:
            safe_name = podcast_name.replace("'", "'\\''")
            filter_parts.append(
                f"[v1]drawtext=text='{safe_name}':"
                f"fontsize=28:fontcolor=white@0.8:"
                f"x=(w-text_w)/2:y=100:"
                f"fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf[v2]"
            )
            last_label = "v2"
        else:
            last_label = "v1"

        # Add episode title below podcast name
        if episode_title:
            safe_title = episode_title[:60].replace("'", "'\\''")
            filter_parts.append(
                f"[{last_label}]drawtext=text='{safe_title}':"
                f"fontsize=18:fontcolor=white@0.5:"
                f"x=(w-text_w)/2:y=145:"
                f"fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf[v3]"
            )
            last_label = "v3"

        # Burn in captions using subtitles filter
        filter_parts.append(
            f"[{last_label}]subtitles={str(srt_path).replace(':', '\\\\:')}:"
            f"force_style='{caption_style}'[vout]"
        )

        filter_complex = ";".join(filter_parts)

        # Codec settings per format
        if format_preset == "tiktok":
            codec_args = ["-c:v", "libx264", "-preset", "medium", "-crf", "23"]
        else:  # shorts
            codec_args = ["-c:v", "libx264", "-preset", "medium", "-crf", "20"]

        cmd = [
            "ffmpeg", "-y",
            "-i", str(audio_clip_path),
            "-filter_complex", filter_complex,
            "-map", "[vout]",
            "-map", "0:a",
            *codec_args,
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p",
            "-r", "30",
            "-t", "30",
            "-movflags", "+faststart",  # Optimize for web playback
            str(output_path),
        ]

        logger.info(f"Rendering clip video: {output_path.name}")
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            logger.error(f"FFmpeg render failed: {result.stderr[:500]}")

            # Fallback: simpler render without waveform
            logger.info("Attempting fallback render (static background)...")
            return self._fallback_render(
                audio_clip_path, srt_path, output_path,
                width, height, caption_style
            )

        file_size = output_path.stat().st_size / (1024 * 1024)
        logger.success(f"Rendered clip: {output_path.name} ({file_size:.1f}MB)")
        return output_path

    def _fallback_render(
        self,
        audio_path: Path,
        srt_path: Path,
        output_path: Path,
        width: int,
        height: int,
        caption_style: str,
    ) -> Path:
        """Simpler FFmpeg render without waveform (more compatible)."""
        cmd = [
            "ffmpeg", "-y",
            "-f", "lavfi",
            "-i", f"color=c=0x0a0a14:s={width}x{height}:d=30:r=30",
            "-i", str(audio_path),
            "-vf", (
                f"subtitles={str(srt_path).replace(':', '\\\\:')}:"
                f"force_style='{caption_style}'"
            ),
            "-map", "0:v",
            "-map", "1:a",
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p",
            "-t", "30",
            "-shortest",
            str(output_path),
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Fallback render also failed: {result.stderr[:500]}")

        return output_path

    def generate_thumbnail(
        self,
        video_path: str | Path,
        output_path: str | Path,
        timestamp: float = 5.0,
    ) -> Path:
        """Extract a frame from the clip video as a thumbnail."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            "ffmpeg", "-y",
            "-i", str(video_path),
            "-ss", str(timestamp),
            "-frames:v", "1",
            "-q:v", "2",
            str(output_path),
        ]

        subprocess.run(cmd, capture_output=True)
        return output_path


def _format_srt_time(seconds: float) -> str:
    """Convert seconds to SRT timestamp format (HH:MM:SS,mmm)."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


async def run_clip():
    """Main clip generation pipeline."""
    console.print("\n[bold cyan]═══ CLIPRADAR: STAGE 5 — CLIP GENERATION ═══[/bold cyan]\n")

    engine, Session = init_db()
    session = Session()

    # Get top viral moments that haven't been clipped yet
    moments = (
        session.query(ViralMoment)
        .filter(ViralMoment.clip_generated == False)
        .order_by(ViralMoment.viral_score.desc())
        .limit(10)
        .all()
    )

    if not moments:
        console.print("[yellow]No moments ready for clipping.[/yellow]")
        return

    generator = ClipGenerator()

    table = Table(title="Generated Clips")
    table.add_column("Episode", max_width=30)
    table.add_column("Score", justify="center")
    table.add_column("Timestamp", justify="center")
    table.add_column("Format", justify="center")
    table.add_column("File", max_width=30)
    table.add_column("Size", justify="center")

    for moment in moments:
        episode = session.query(Episode).get(moment.episode_id)
        if not episode or not episode.local_audio_path:
            logger.warning(f"No audio for episode {moment.episode_id}")
            continue

        audio_path = Path(episode.local_audio_path)
        if not audio_path.exists():
            continue

        # Load transcript
        analysis_path = settings.transcripts_dir / f"{episode.id}__analysis.json"
        transcript = {}
        if analysis_path.exists():
            with open(analysis_path) as f:
                analysis = json.load(f)
                transcript = analysis.get("transcript", {})

        # Generate file paths
        clip_id = f"{episode.id}__{moment.id}"
        audio_clip_path = settings.clips_dir / f"{clip_id}_audio.mp3"
        srt_path = settings.clips_dir / f"{clip_id}.srt"

        for fmt in ["shorts", "tiktok"]:
            video_path = settings.clips_dir / f"{clip_id}_{fmt}.mp4"
            thumb_path = settings.clips_dir / f"{clip_id}_{fmt}_thumb.jpg"

            try:
                # Step 1: Extract audio segment
                generator.extract_audio_clip(
                    audio_path,
                    moment.timestamp_start_ms,
                    moment.duration_ms,
                    audio_clip_path,
                )

                # Step 2: Generate captions
                generator.generate_srt_captions(
                    transcript,
                    moment.timestamp_start_ms,
                    moment.timestamp_end_ms,
                    srt_path,
                )

                # Step 3: Render video
                generator.render_clip_video(
                    audio_clip_path,
                    srt_path,
                    video_path,
                    podcast_name=episode.podcast.name if episode.podcast else "",
                    episode_title=episode.title,
                    format_preset=fmt,
                )

                # Step 4: Generate thumbnail
                generator.generate_thumbnail(video_path, thumb_path)

                # Store in DB
                file_size = video_path.stat().st_size
                db_clip = GeneratedClip(
                    moment_id=moment.id,
                    format=fmt,
                    resolution="1080x1920",
                    file_path=str(video_path),
                    file_size_bytes=file_size,
                    caption_path=str(srt_path),
                    thumbnail_path=str(thumb_path),
                )
                session.add(db_clip)

                table.add_row(
                    episode.title[:28],
                    f"{moment.viral_score:.0f}",
                    f"{moment.timestamp_start_ms // 60000}:{(moment.timestamp_start_ms // 1000) % 60:02d}",
                    fmt.upper(),
                    video_path.name,
                    f"{file_size / (1024*1024):.1f}MB",
                )

            except Exception as e:
                logger.error(f"Clip generation failed for moment {moment.id}: {e}")

        moment.clip_generated = True
        moment.clip_path = str(settings.clips_dir / f"{clip_id}_shorts.mp4")
        session.commit()

    console.print(table)
    console.print("\n[bold green]Clip generation complete.[/bold green]")
    console.print(f"Clips saved to: {settings.clips_dir}\n")
    session.close()


if __name__ == "__main__":
    import asyncio
    asyncio.run(run_clip())
