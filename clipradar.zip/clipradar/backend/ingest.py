"""
Stage 1: Podcast Ingestion
─────────────────────────
Fetches podcast rankings from Spotify, resolves RSS feeds,
and downloads latest episode audio for processing.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

import feedparser
import httpx
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from loguru import logger
from rich.console import Console
from rich.table import Table

from backend.config import settings
from backend.models import Podcast, Episode, init_db

console = Console()

# ─── Comedy Podcast Registry ────────────────────────────────────
# Spotify show IDs for top comedy podcasts
# You can find these by searching on Spotify and grabbing the ID from the URL
COMEDY_PODCAST_REGISTRY = [
    {
        "name": "Kill Tony",
        "spotify_id": "0MprEJJgUVTKJzIvpmfFMb",
        "rss_url": "https://feeds.simplecast.com/1Y2ZURN3",
        "genre": "Stand-Up/Improv",
    },
    {
        "name": "Bad Friends",
        "spotify_id": "6ZoUMFIhIO2iCAZlpMOLMi",
        "rss_url": "https://feeds.simplecast.com/bU0ywDaZ",
        "genre": "Comedy/Talk",
    },
    {
        "name": "Flagrant",
        "spotify_id": "0xDESMGkBBQbKpNXBJPRGJ",
        "rss_url": "https://feeds.simplecast.com/AgQMNleo",
        "genre": "Comedy/Culture",
    },
    {
        "name": "Matt and Shane's Secret Podcast",
        "spotify_id": "2J8gMnDwil5HEzJjqx3mAt",
        "rss_url": None,  # Patreon-gated, needs manual RSS
        "genre": "Comedy",
    },
    {
        "name": "Are You Garbage?",
        "spotify_id": "3b2tBGJWxZOj0gIorXaD7E",
        "rss_url": "https://feeds.simplecast.com/vqB_JKdQ",
        "genre": "Comedy/Interview",
    },
    {
        "name": "This Past Weekend",
        "spotify_id": "5VjfzfOPgKJalkVSiMrh5Z",
        "rss_url": "https://feeds.megaphone.fm/TPW1472523886",
        "genre": "Comedy/Stories",
    },
    {
        "name": "Whiskey Ginger",
        "spotify_id": "1bEEfOZTGBN1muj3R3nYF5",
        "rss_url": "https://feeds.simplecast.com/7y1FVb0h",
        "genre": "Comedy/Interview",
    },
    {
        "name": "Hey Babe!",
        "spotify_id": "5dKCkxCdkNzVhGn3VKY87b",
        "rss_url": "https://feeds.simplecast.com/Bsh_0DIq",
        "genre": "Comedy",
    },
]


class SpotifyIngestor:
    """Fetches podcast metadata and episode info from Spotify API."""

    def __init__(self):
        if not settings.spotify_client_id or not settings.spotify_client_secret:
            raise ValueError(
                "Spotify credentials required. Set SPOTIFY_CLIENT_ID and "
                "SPOTIFY_CLIENT_SECRET in config/.env"
            )
        self.sp = spotipy.Spotify(
            auth_manager=SpotifyClientCredentials(
                client_id=settings.spotify_client_id,
                client_secret=settings.spotify_client_secret,
            )
        )
        logger.info("Spotify client initialized")

    def get_show_metadata(self, spotify_id: str) -> dict:
        """Fetch podcast show metadata from Spotify."""
        try:
            show = self.sp.show(spotify_id, market="US")
            return {
                "name": show["name"],
                "publisher": show["publisher"],
                "description": show["description"],
                "total_episodes": show["total_episodes"],
                "images": show.get("images", []),
                "languages": show.get("languages", []),
            }
        except Exception as e:
            logger.error(f"Failed to fetch show {spotify_id}: {e}")
            return {}

    def get_latest_episodes(self, spotify_id: str, limit: int = 5) -> list[dict]:
        """Fetch recent episodes for a show."""
        try:
            result = self.sp.show_episodes(spotify_id, limit=limit, market="US")
            episodes = []
            for ep in result.get("items", []):
                episodes.append({
                    "spotify_id": ep["id"],
                    "title": ep["name"],
                    "description": ep.get("description", ""),
                    "duration_ms": ep["duration_ms"],
                    "release_date": ep["release_date"],
                    "audio_preview_url": ep.get("audio_preview_url"),
                })
            return episodes
        except Exception as e:
            logger.error(f"Failed to fetch episodes for {spotify_id}: {e}")
            return []


class RSSIngestor:
    """Fetches episode audio URLs from podcast RSS feeds."""

    @staticmethod
    async def parse_feed(rss_url: str) -> list[dict]:
        """Parse RSS feed and extract episode info with audio URLs."""
        if not rss_url:
            return []

        try:
            async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
                response = await client.get(rss_url)
                response.raise_for_status()

            feed = feedparser.parse(response.text)
            episodes = []

            for entry in feed.entries[:10]:  # Latest 10 episodes
                audio_url = None

                # Extract audio URL from enclosures
                for enc in entry.get("enclosures", []):
                    if "audio" in enc.get("type", ""):
                        audio_url = enc.get("href") or enc.get("url")
                        break

                # Fallback: check links
                if not audio_url:
                    for link in entry.get("links", []):
                        if "audio" in link.get("type", ""):
                            audio_url = link.get("href")
                            break

                if audio_url:
                    # Parse duration from itunes:duration tag
                    duration_str = entry.get("itunes_duration", "0")
                    duration_ms = _parse_duration(duration_str)

                    episodes.append({
                        "title": entry.get("title", "Unknown"),
                        "rss_guid": entry.get("id", entry.get("link", "")),
                        "audio_url": audio_url,
                        "duration_ms": duration_ms,
                        "release_date": entry.get("published", ""),
                        "description": entry.get("summary", ""),
                    })

            logger.info(f"Parsed {len(episodes)} episodes from RSS: {rss_url}")
            return episodes

        except Exception as e:
            logger.error(f"Failed to parse RSS feed {rss_url}: {e}")
            return []


class AudioDownloader:
    """Downloads episode audio files for processing."""

    @staticmethod
    async def download_episode(
        audio_url: str,
        podcast_name: str,
        episode_title: str,
    ) -> Optional[Path]:
        """Download episode audio to local storage."""
        # Sanitize filename
        safe_name = re.sub(r'[^\w\s-]', '', podcast_name).strip().replace(' ', '_')
        safe_title = re.sub(r'[^\w\s-]', '', episode_title).strip().replace(' ', '_')[:80]
        filename = f"{safe_name}__{safe_title}.mp3"
        filepath = settings.audio_dir / filename

        if filepath.exists():
            logger.info(f"Audio already exists: {filepath}")
            return filepath

        try:
            logger.info(f"Downloading: {episode_title}")
            async with httpx.AsyncClient(follow_redirects=True, timeout=300) as client:
                async with client.stream("GET", audio_url) as response:
                    response.raise_for_status()
                    total = int(response.headers.get("content-length", 0))

                    with open(filepath, "wb") as f:
                        downloaded = 0
                        async for chunk in response.aiter_bytes(chunk_size=8192):
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total > 0:
                                pct = (downloaded / total) * 100
                                if downloaded % (1024 * 1024) < 8192:  # Log every ~1MB
                                    logger.debug(f"  {pct:.0f}% ({downloaded // 1024 // 1024}MB)")

            file_size_mb = filepath.stat().st_size / (1024 * 1024)
            logger.success(f"Downloaded: {filename} ({file_size_mb:.1f}MB)")
            return filepath

        except Exception as e:
            logger.error(f"Failed to download {audio_url}: {e}")
            if filepath.exists():
                filepath.unlink()  # Clean up partial download
            return None


def _parse_duration(duration_str: str) -> int:
    """Parse duration string (HH:MM:SS or seconds) to milliseconds."""
    try:
        if ":" in str(duration_str):
            parts = str(duration_str).split(":")
            if len(parts) == 3:
                h, m, s = parts
                return (int(h) * 3600 + int(m) * 60 + int(float(s))) * 1000
            elif len(parts) == 2:
                m, s = parts
                return (int(m) * 60 + int(float(s))) * 1000
        return int(float(duration_str)) * 1000
    except (ValueError, TypeError):
        return 0


async def run_ingest():
    """Main ingest pipeline: fetch rankings, parse RSS, download audio."""
    console.print("\n[bold cyan]═══ CLIPRADAR: STAGE 1 — INGEST ═══[/bold cyan]\n")

    engine, Session = init_db()
    session = Session()

    # Initialize Spotify client
    try:
        spotify = SpotifyIngestor()
    except ValueError as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        return

    table = Table(title="Podcast Ingestion Results")
    table.add_column("Podcast", style="bold")
    table.add_column("Episodes Found", justify="center")
    table.add_column("Audio URLs", justify="center")
    table.add_column("Status", justify="center")

    for pod_config in COMEDY_PODCAST_REGISTRY:
        name = pod_config["name"]

        # Check if podcast exists in DB
        existing = session.query(Podcast).filter_by(name=name).first()
        if not existing:
            existing = Podcast(
                name=name,
                spotify_id=pod_config["spotify_id"],
                rss_url=pod_config.get("rss_url"),
                genre=pod_config.get("genre", "Comedy"),
            )
            session.add(existing)
            session.commit()

        # Fetch Spotify metadata
        meta = spotify.get_show_metadata(pod_config["spotify_id"])
        if meta:
            existing.host = meta.get("publisher", "")
            if meta.get("images"):
                existing.cover_url = meta["images"][0]["url"]
            session.commit()

        # Fetch episodes from Spotify
        sp_episodes = spotify.get_latest_episodes(pod_config["spotify_id"], limit=3)

        # Parse RSS for audio URLs
        rss_episodes = []
        if pod_config.get("rss_url"):
            rss_episodes = await RSSIngestor.parse_feed(pod_config["rss_url"])

        # Merge: match Spotify metadata with RSS audio URLs
        audio_count = 0
        for sp_ep in sp_episodes:
            # Check if episode already in DB
            ep_exists = session.query(Episode).filter_by(
                spotify_id=sp_ep["spotify_id"]
            ).first()

            if not ep_exists:
                # Try to find matching RSS episode by title similarity
                audio_url = _match_rss_audio(sp_ep["title"], rss_episodes)

                new_ep = Episode(
                    podcast_id=existing.id,
                    title=sp_ep["title"],
                    spotify_id=sp_ep["spotify_id"],
                    audio_url=audio_url,
                    duration_ms=sp_ep["duration_ms"],
                    release_date=datetime.fromisoformat(
                        sp_ep["release_date"]
                    ) if sp_ep["release_date"] else None,
                    description=sp_ep.get("description", ""),
                )
                session.add(new_ep)
                if audio_url:
                    audio_count += 1

        session.commit()

        status = "[green]✓[/green]" if audio_count > 0 else "[yellow]⚠ No audio[/yellow]"
        table.add_row(name, str(len(sp_episodes)), str(audio_count), status)

    console.print(table)
    console.print("\n[bold green]Ingest complete.[/bold green]\n")
    session.close()


def _match_rss_audio(spotify_title: str, rss_episodes: list[dict]) -> Optional[str]:
    """Fuzzy-match a Spotify episode title to an RSS entry to get the audio URL."""
    if not rss_episodes:
        return None

    sp_title_lower = spotify_title.lower().strip()

    # Try exact-ish match first
    for rss_ep in rss_episodes:
        rss_title_lower = rss_ep["title"].lower().strip()
        if sp_title_lower == rss_title_lower:
            return rss_ep["audio_url"]

    # Try substring match
    for rss_ep in rss_episodes:
        rss_title_lower = rss_ep["title"].lower().strip()
        # Check if significant overlap
        sp_words = set(sp_title_lower.split())
        rss_words = set(rss_title_lower.split())
        overlap = sp_words & rss_words
        if len(overlap) >= max(2, len(sp_words) * 0.5):
            return rss_ep["audio_url"]

    # Fallback: return most recent RSS episode
    if rss_episodes:
        return rss_episodes[0]["audio_url"]

    return None


if __name__ == "__main__":
    import asyncio
    asyncio.run(run_ingest())
