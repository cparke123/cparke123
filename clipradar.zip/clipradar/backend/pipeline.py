"""
ClipRadar Pipeline Orchestrator
────────────────────────────────
Runs the full pipeline or individual stages.

Usage:
    python -m backend.pipeline --full     # Run all stages
    python -m backend.pipeline --stage 1  # Run specific stage
"""

import asyncio
import sys
import time

import typer
from loguru import logger
from rich.console import Console
from rich.panel import Panel

from backend.ingest import run_ingest
from backend.signals import run_signals
from backend.transcribe import run_transcribe
from backend.detect import run_detect
from backend.clip import run_clip

console = Console()
app = typer.Typer(help="ClipRadar — Viral Podcast Clip Pipeline")


STAGES = {
    1: ("Ingest", "Fetch podcast rankings + episode metadata", run_ingest),
    2: ("Signal Scan", "Monitor social platforms for viral signals", run_signals),
    3: ("Transcribe", "Transcribe audio + analyze energy/laughter", run_transcribe),
    4: ("Detect", "Score and rank viral moments", run_detect),
    5: ("Clip", "Generate 30s clips for Shorts/TikTok", run_clip),
}


@app.command()
def run(
    full: bool = typer.Option(False, "--full", help="Run all pipeline stages"),
    stage: int = typer.Option(0, "--stage", "-s", help="Run specific stage (1-5)"),
    from_stage: int = typer.Option(0, "--from", help="Run from stage N onwards"),
):
    """Run the ClipRadar pipeline."""

    console.print(Panel.fit(
        "[bold white]⚡ CLIPRADAR[/bold white]\n"
        "[dim]Viral Podcast Intelligence Pipeline[/dim]",
        border_style="bright_red",
        padding=(1, 4),
    ))

    if full:
        stages_to_run = list(STAGES.keys())
    elif stage > 0:
        if stage not in STAGES:
            console.print(f"[red]Invalid stage: {stage}. Choose 1-5.[/red]")
            raise typer.Exit(1)
        stages_to_run = [stage]
    elif from_stage > 0:
        stages_to_run = [s for s in STAGES if s >= from_stage]
    else:
        # Show menu
        console.print("\n[bold]Pipeline Stages:[/bold]\n")
        for num, (name, desc, _) in STAGES.items():
            console.print(f"  [cyan]{num}[/cyan]. [bold]{name}[/bold] — {desc}")
        console.print(
            "\n[dim]Usage: python -m backend.pipeline --full"
            " | --stage N | --from N[/dim]\n"
        )
        raise typer.Exit(0)

    # Run selected stages
    total_start = time.time()

    for stage_num in stages_to_run:
        name, desc, func = STAGES[stage_num]
        console.print(f"\n[bold magenta]▶ Stage {stage_num}: {name}[/bold magenta]")
        stage_start = time.time()

        try:
            asyncio.run(func())
        except KeyboardInterrupt:
            console.print("\n[yellow]Pipeline interrupted by user.[/yellow]")
            raise typer.Exit(0)
        except Exception as e:
            logger.error(f"Stage {stage_num} failed: {e}")
            console.print(f"[bold red]✗ Stage {stage_num} failed: {e}[/bold red]")
            if not full:
                raise typer.Exit(1)
            continue

        elapsed = time.time() - stage_start
        console.print(f"[dim]  └─ Completed in {elapsed:.1f}s[/dim]")

    total_elapsed = time.time() - total_start
    console.print(f"\n[bold green]Pipeline complete in {total_elapsed:.1f}s[/bold green]\n")


if __name__ == "__main__":
    app()
