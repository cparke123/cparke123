"""ClipRadar database models."""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Text, Boolean, JSON,
    ForeignKey, Index, create_engine
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()


class Podcast(Base):
    """A tracked comedy podcast."""
    __tablename__ = "podcasts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False, unique=True)
    host = Column(String(255))
    genre = Column(String(100))
    spotify_id = Column(String(100), unique=True, index=True)
    rss_url = Column(Text)
    apple_id = Column(String(100))
    cover_url = Column(Text)
    weekly_listeners = Column(Integer, default=0)
    rank = Column(Integer)
    rank_trend = Column(Float, default=0.0)  # % change week over week
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    episodes = relationship("Episode", back_populates="podcast", cascade="all, delete-orphan")


class Episode(Base):
    """A single podcast episode."""
    __tablename__ = "episodes"

    id = Column(Integer, primary_key=True, autoincrement=True)
    podcast_id = Column(Integer, ForeignKey("podcasts.id"), nullable=False)
    title = Column(String(500), nullable=False)
    spotify_id = Column(String(100), index=True)
    rss_guid = Column(String(500))
    audio_url = Column(Text)  # Direct MP3 link from RSS
    local_audio_path = Column(Text)
    duration_ms = Column(Integer)
    release_date = Column(DateTime)
    description = Column(Text)
    transcribed = Column(Boolean, default=False)
    transcript_path = Column(Text)
    processed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    podcast = relationship("Podcast", back_populates="episodes")
    moments = relationship("ViralMoment", back_populates="episode", cascade="all, delete-orphan")
    signals = relationship("SocialSignal", back_populates="episode", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_episode_podcast_release", "podcast_id", "release_date"),
    )


class ViralMoment(Base):
    """A detected viral-worthy moment in an episode."""
    __tablename__ = "viral_moments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    episode_id = Column(Integer, ForeignKey("episodes.id"), nullable=False)
    timestamp_start_ms = Column(Integer, nullable=False)  # Start of moment in ms
    timestamp_end_ms = Column(Integer, nullable=False)    # End of moment in ms
    duration_ms = Column(Integer, default=30000)

    # Scoring
    viral_score = Column(Float, default=0.0)         # Composite 0-100
    social_score = Column(Float, default=0.0)         # From social signals
    audio_energy_score = Column(Float, default=0.0)   # From audio analysis
    transcript_score = Column(Float, default=0.0)     # From NLP/pattern matching
    laughter_score = Column(Float, default=0.0)       # Laughter/crowd detection

    # Metadata
    label = Column(String(255))  # Human-readable description
    transcript_snippet = Column(Text)
    speaker = Column(String(100))
    tags = Column(JSON)  # e.g., ["roast", "callback", "crowd_work"]

    # Clip generation status
    clip_generated = Column(Boolean, default=False)
    clip_path = Column(Text)
    clip_format = Column(String(20))

    created_at = Column(DateTime, default=datetime.utcnow)

    episode = relationship("Episode", back_populates="moments")

    __table_args__ = (
        Index("ix_moment_score", "viral_score"),
        Index("ix_moment_episode", "episode_id", "viral_score"),
    )


class SocialSignal(Base):
    """A social media signal associated with an episode."""
    __tablename__ = "social_signals"

    id = Column(Integer, primary_key=True, autoincrement=True)
    episode_id = Column(Integer, ForeignKey("episodes.id"), nullable=False)
    platform = Column(String(50), nullable=False)  # reddit, twitter, youtube, tiktok
    signal_type = Column(String(50))  # mention, comment, clip_share, quote_tweet
    content = Column(Text)
    url = Column(Text)
    engagement = Column(Integer, default=0)  # upvotes, likes, retweets
    timestamp_ref = Column(String(20))  # If the post references a specific timestamp
    detected_at = Column(DateTime, default=datetime.utcnow)

    episode = relationship("Episode", back_populates="signals")


class GeneratedClip(Base):
    """A generated clip ready for upload."""
    __tablename__ = "generated_clips"

    id = Column(Integer, primary_key=True, autoincrement=True)
    moment_id = Column(Integer, ForeignKey("viral_moments.id"), nullable=False)
    format = Column(String(20))  # shorts, tiktok
    resolution = Column(String(20))  # 1080x1920
    file_path = Column(Text)
    file_size_bytes = Column(Integer)
    caption_path = Column(Text)  # SRT file path
    thumbnail_path = Column(Text)
    uploaded = Column(Boolean, default=False)
    upload_url = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db(database_url: str = "sqlite:///./clipradar.db"):
    """Initialize database and create all tables."""
    engine = create_engine(database_url.replace("+aiosqlite", "").replace("+asyncpg", ""))
    Base.metadata.create_all(engine)
    return engine, sessionmaker(bind=engine)
