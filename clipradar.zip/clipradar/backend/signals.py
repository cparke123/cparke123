"""
Stage 2: Social Signal Scanning
────────────────────────────────
Monitors Reddit, YouTube, and Twitter/X for episode mentions,
clip shares, and engagement spikes to build viral proxy scores.
"""

import re
from datetime import datetime, timedelta
from typing import Optional

import praw
from loguru import logger
from rich.console import Console
from rich.table import Table

from backend.config import settings
from backend.models import Episode, SocialSignal, init_db

console = Console()

# ─── Subreddits to Monitor ──────────────────────────────────────
COMEDY_SUBREDDITS = [
    "Killtony",
    "badfriendspod",
    "Flagrant2",
    "TheoVon",
    "StandUpComedy",
    "podcasts",
    "Standup",
    "AreYouGarbage",
    "MSsecretpodcast",
]

# Keywords that indicate a specific moment/timestamp reference
TIMESTAMP_PATTERNS = [
    r'(\d{1,2}:\d{2}:\d{2})',           # 1:23:45
    r'(\d{1,2}:\d{2})',                   # 23:45
    r'at\s+(\d+)\s*min',                  # at 45 min
    r'around\s+(\d+)\s*min',              # around 45 min
    r'(\d+)\s*minute\s*mark',             # 45 minute mark
]

# High-signal keywords that indicate viral moments
VIRAL_KEYWORDS = [
    "funniest", "lost it", "died laughing", "can't stop", "crying",
    "best moment", "clip this", "someone clip", "this part", "highlight",
    "best episode", "roast", "killed it", "destroyed", "murdered",
    "standing ovation", "crowd went crazy", "insane", "legendary",
    "golden ticket", "regular", "minute man",  # Kill Tony specific
]


class RedditScanner:
    """Scans Reddit for podcast episode mentions and viral signals."""

    def __init__(self):
        if not settings.reddit_client_id or not settings.reddit_client_secret:
            raise ValueError(
                "Reddit credentials required. Set REDDIT_CLIENT_ID and "
                "REDDIT_CLIENT_SECRET in config/.env"
            )
        self.reddit = praw.Reddit(
            client_id=settings.reddit_client_id,
            client_secret=settings.reddit_client_secret,
            user_agent=settings.reddit_user_agent,
        )
        logger.info("Reddit client initialized (read-only)")

    def scan_subreddit(
        self,
        subreddit_name: str,
        episode_title: str,
        podcast_name: str,
        lookback_days: int = 7,
    ) -> list[dict]:
        """Scan a subreddit for mentions of a specific episode."""
        signals = []
        try:
            subreddit = self.reddit.subreddit(subreddit_name)

            # Search for episode mentions
            search_queries = [
                episode_title[:50],
                f"{podcast_name} new episode",
            ]

            for query in search_queries:
                for submission in subreddit.search(
                    query, time_filter="week", sort="relevance", limit=25
                ):
                    # Check if post is about this episode
                    relevance = _calculate_relevance(
                        submission.title + " " + (submission.selftext or ""),
                        episode_title,
                        podcast_name,
                    )

                    if relevance < 0.3:
                        continue

                    signal = {
                        "platform": "reddit",
                        "signal_type": "post",
                        "content": submission.title,
                        "url": f"https://reddit.com{submission.permalink}",
                        "engagement": submission.score + submission.num_comments,
                        "timestamp_ref": _extract_timestamp_ref(
                            submission.title + " " + (submission.selftext or "")
                        ),
                        "viral_keywords": _count_viral_keywords(
                            submission.title + " " + (submission.selftext or "")
                        ),
                    }
                    signals.append(signal)

                    # Also scan top comments for timestamp refs and viral indicators
                    submission.comment_sort = "top"
                    submission.comments.replace_more(limit=0)
                    for comment in submission.comments[:20]:
                        comment_text = comment.body or ""
                        ts_ref = _extract_timestamp_ref(comment_text)
                        viral_count = _count_viral_keywords(comment_text)

                        if ts_ref or viral_count >= 2 or comment.score >= 50:
                            signals.append({
                                "platform": "reddit",
                                "signal_type": "comment",
                                "content": comment_text[:500],
                                "url": f"https://reddit.com{comment.permalink}",
                                "engagement": comment.score,
                                "timestamp_ref": ts_ref,
                                "viral_keywords": viral_count,
                            })

        except Exception as e:
            logger.error(f"Reddit scan error for r/{subreddit_name}: {e}")

        return signals

    def scan_all_subreddits(
        self,
        episode_title: str,
        podcast_name: str,
    ) -> list[dict]:
        """Scan all comedy subreddits for episode signals."""
        all_signals = []
        for sub in COMEDY_SUBREDDITS:
            logger.debug(f"Scanning r/{sub} for '{episode_title[:40]}...'")
            signals = self.scan_subreddit(sub, episode_title, podcast_name)
            all_signals.extend(signals)
        return all_signals


class YouTubeScanner:
    """Scans YouTube for episode uploads and comment engagement."""

    def __init__(self):
        if not settings.youtube_api_key:
            logger.warning("YouTube API key not set — skipping YouTube scanning")
            self.client = None
            return

        from googleapiclient.discovery import build
        self.client = build("youtube", "v3", developerKey=settings.youtube_api_key)
        logger.info("YouTube client initialized")

    def search_episode_uploads(self, podcast_name: str, episode_title: str) -> list[dict]:
        """Find YouTube uploads of podcast episodes (clips + full episodes)."""
        if not self.client:
            return []

        signals = []
        try:
            query = f"{podcast_name} {episode_title[:30]}"
            response = self.client.search().list(
                part="snippet",
                q=query,
                type="video",
                order="relevance",
                publishedAfter=(datetime.utcnow() - timedelta(days=14)).isoformat() + "Z",
                maxResults=10,
            ).execute()

            for item in response.get("items", []):
                video_id = item["id"]["videoId"]
                snippet = item["snippet"]

                # Get video stats
                stats = self.client.videos().list(
                    part="statistics",
                    id=video_id,
                ).execute()

                video_stats = stats["items"][0]["statistics"] if stats["items"] else {}

                signals.append({
                    "platform": "youtube",
                    "signal_type": "video_upload",
                    "content": snippet["title"],
                    "url": f"https://youtube.com/watch?v={video_id}",
                    "engagement": int(video_stats.get("viewCount", 0))
                                + int(video_stats.get("likeCount", 0)) * 5
                                + int(video_stats.get("commentCount", 0)) * 10,
                    "timestamp_ref": None,
                    "viral_keywords": _count_viral_keywords(snippet["title"]),
                    "view_count": int(video_stats.get("viewCount", 0)),
                    "comment_count": int(video_stats.get("commentCount", 0)),
                })

                # Scan comments for timestamp references
                try:
                    comments_response = self.client.commentThreads().list(
                        part="snippet",
                        videoId=video_id,
                        order="relevance",
                        maxResults=50,
                    ).execute()

                    for thread in comments_response.get("items", []):
                        comment = thread["snippet"]["topLevelComment"]["snippet"]
                        comment_text = comment["textDisplay"]
                        ts_ref = _extract_timestamp_ref(comment_text)

                        if ts_ref or _count_viral_keywords(comment_text) >= 2:
                            signals.append({
                                "platform": "youtube",
                                "signal_type": "comment",
                                "content": comment_text[:500],
                                "url": f"https://youtube.com/watch?v={video_id}",
                                "engagement": int(comment.get("likeCount", 0)),
                                "timestamp_ref": ts_ref,
                                "viral_keywords": _count_viral_keywords(comment_text),
                            })
                except Exception:
                    pass  # Comments may be disabled

        except Exception as e:
            logger.error(f"YouTube scan error: {e}")

        return signals


# ─── Signal Analysis Helpers ─────────────────────────────────────

def _calculate_relevance(text: str, episode_title: str, podcast_name: str) -> float:
    """Calculate how relevant a text is to a specific episode. Returns 0-1."""
    text_lower = text.lower()
    title_words = set(episode_title.lower().split())
    podcast_words = set(podcast_name.lower().split())

    # Count matching words
    text_words = set(text_lower.split())
    title_overlap = len(title_words & text_words) / max(len(title_words), 1)
    podcast_overlap = len(podcast_words & text_words) / max(len(podcast_words), 1)

    return (title_overlap * 0.6) + (podcast_overlap * 0.4)


def _extract_timestamp_ref(text: str) -> Optional[str]:
    """Extract timestamp references from text (e.g., '1:23:45', 'at 45 min')."""
    for pattern in TIMESTAMP_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1)
    return None


def _count_viral_keywords(text: str) -> int:
    """Count how many viral indicator keywords appear in text."""
    text_lower = text.lower()
    return sum(1 for kw in VIRAL_KEYWORDS if kw in text_lower)


def calculate_social_heat_score(signals: list[dict]) -> dict:
    """
    Calculate composite social heat score for an episode.

    Returns:
        {
            "total_score": float (0-100),
            "mention_count": int,
            "total_engagement": int,
            "timestamp_refs": list of referenced timestamps,
            "viral_keyword_density": float,
            "top_signals": list of highest-engagement signals,
        }
    """
    if not signals:
        return {"total_score": 0, "mention_count": 0, "total_engagement": 0,
                "timestamp_refs": [], "viral_keyword_density": 0, "top_signals": []}

    total_engagement = sum(s.get("engagement", 0) for s in signals)
    mention_count = len(signals)
    timestamp_refs = [s["timestamp_ref"] for s in signals if s.get("timestamp_ref")]
    total_viral_keywords = sum(s.get("viral_keywords", 0) for s in signals)

    # Score components (each 0-25, total max 100)
    engagement_score = min(25, (total_engagement / 1000) * 25)
    mention_score = min(25, (mention_count / 50) * 25)
    timestamp_score = min(25, (len(timestamp_refs) / 10) * 25)
    viral_kw_score = min(25, (total_viral_keywords / 20) * 25)

    total_score = engagement_score + mention_score + timestamp_score + viral_kw_score

    # Sort signals by engagement
    sorted_signals = sorted(signals, key=lambda s: s.get("engagement", 0), reverse=True)

    return {
        "total_score": round(total_score, 1),
        "mention_count": mention_count,
        "total_engagement": total_engagement,
        "timestamp_refs": timestamp_refs,
        "viral_keyword_density": total_viral_keywords / max(mention_count, 1),
        "top_signals": sorted_signals[:5],
    }


async def run_signals():
    """Main signal scanning pipeline."""
    console.print("\n[bold cyan]═══ CLIPRADAR: STAGE 2 — SIGNAL SCAN ═══[/bold cyan]\n")

    engine, Session = init_db()
    session = Session()

    # Get recent unprocessed episodes
    recent_episodes = (
        session.query(Episode)
        .filter(Episode.release_date >= datetime.utcnow() - timedelta(days=14))
        .order_by(Episode.release_date.desc())
        .limit(20)
        .all()
    )

    if not recent_episodes:
        console.print("[yellow]No recent episodes to scan.[/yellow]")
        return

    # Initialize scanners
    try:
        reddit = RedditScanner()
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        return

    yt = YouTubeScanner()

    table = Table(title="Social Signal Scan Results")
    table.add_column("Episode", style="bold", max_width=40)
    table.add_column("Reddit", justify="center")
    table.add_column("YouTube", justify="center")
    table.add_column("Heat Score", justify="center")
    table.add_column("Timestamps", justify="center")

    for episode in recent_episodes:
        podcast = episode.podcast

        # Reddit signals
        reddit_signals = reddit.scan_all_subreddits(episode.title, podcast.name)

        # YouTube signals
        yt_signals = yt.search_episode_uploads(podcast.name, episode.title)

        # Combine all signals
        all_signals = reddit_signals + yt_signals

        # Store signals in DB
        for sig in all_signals:
            db_signal = SocialSignal(
                episode_id=episode.id,
                platform=sig["platform"],
                signal_type=sig["signal_type"],
                content=sig.get("content", "")[:500],
                url=sig.get("url"),
                engagement=sig.get("engagement", 0),
                timestamp_ref=sig.get("timestamp_ref"),
            )
            session.add(db_signal)

        # Calculate heat score
        heat = calculate_social_heat_score(all_signals)

        heat_color = "green" if heat["total_score"] >= 60 else "yellow" if heat["total_score"] >= 30 else "dim"
        table.add_row(
            episode.title[:38] + "..." if len(episode.title) > 40 else episode.title,
            str(len(reddit_signals)),
            str(len(yt_signals)),
            f"[{heat_color}]{heat['total_score']:.0f}[/{heat_color}]",
            str(len(heat["timestamp_refs"])),
        )

    session.commit()
    console.print(table)
    console.print("\n[bold green]Signal scan complete.[/bold green]\n")
    session.close()


if __name__ == "__main__":
    import asyncio
    asyncio.run(run_signals())
