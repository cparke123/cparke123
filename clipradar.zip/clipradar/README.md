# ClipRadar — Viral Podcast Clip Pipeline

A production pipeline that tracks top comedy podcasts, detects viral moments using social signal proxies and audio analysis, and generates 30-second clips formatted for YouTube Shorts and TikTok.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     CLIPRADAR PIPELINE                   │
├──────────┬──────────┬───────────┬───────────┬───────────┤
│  INGEST  │  SIGNAL  │ TRANSCRIBE│  DETECT   │   CLIP    │
│          │  SCAN    │ + ANALYZE │  MOMENTS  │ GENERATE  │
├──────────┼──────────┼───────────┼───────────┼───────────┤
│ Spotify  │ Reddit   │ Whisper   │ Composite │ FFmpeg    │
│ API      │ API      │ (faster-  │ scoring   │ (extract  │
│ (charts) │          │  whisper) │ engine    │  + format │
│          │ Twitter/ │           │           │  9:16)    │
│ RSS Feed │ X API    │ Pyannote  │ Laugh     │           │
│ (audio)  │          │ (speaker  │ detection │ Whisper   │
│          │ YouTube  │  diarize) │           │ (auto     │
│ Apple    │ Data API │           │ Energy    │  caption) │
│ Podcasts │          │           │ spikes    │           │
│ (rank)   │ TikTok   │           │           │ Auto-     │
│          │ mentions │           │ Topic     │ upload    │
│          │          │           │ clusters  │ (YT/TT)  │
└──────────┴──────────┴───────────┴───────────┴───────────┘
                          │
                    ┌─────┴─────┐
                    │ PostgreSQL │
                    │ + Redis    │
                    └───────────┘
```

## Quick Start

### 1. Prerequisites

- Python 3.11+
- FFmpeg (`brew install ffmpeg` or `sudo apt install ffmpeg`)
- PostgreSQL (or use SQLite for local dev)
- Redis (optional, for caching)

### 2. Install Dependencies

```bash
cd clipradar
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Configure API Keys

```bash
cp config/.env.example config/.env
# Edit config/.env with your API keys
```

**Required keys:**
- `SPOTIFY_CLIENT_ID` / `SPOTIFY_CLIENT_SECRET` — [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
- `REDDIT_CLIENT_ID` / `REDDIT_CLIENT_SECRET` — [Reddit App Preferences](https://www.reddit.com/prefs/apps)
- `OPENAI_API_KEY` — For Whisper API (or use local faster-whisper, no key needed)

**Optional keys:**
- `TWITTER_BEARER_TOKEN` — For X/Twitter social signal scanning
- `YOUTUBE_API_KEY` — For YouTube comment analysis
- `HUGGINGFACE_TOKEN` — For Pyannote speaker diarization

### 4. Initialize Database

```bash
python scripts/init_db.py
```

### 5. Run the Pipeline

```bash
# Full pipeline: ingest → scan → detect → clip
python -m backend.pipeline --full

# Or run individual stages:
python -m backend.ingest        # Fetch podcast rankings + episodes
python -m backend.signals       # Scan social signals
python -m backend.transcribe    # Transcribe with Whisper
python -m backend.detect        # Score viral moments
python -m backend.clip          # Generate 30s clips
```

### 6. Run the Dashboard

```bash
cd frontend
npm install
npm run dev
```

## Pipeline Stages (Detail)

### Stage 1: Ingest
- Pulls top comedy podcast rankings from Spotify API + Apple Podcasts RSS
- Downloads latest episode audio via RSS feed (direct MP3 links)
- Stores episode metadata in PostgreSQL

### Stage 2: Signal Scanning
- Monitors Reddit (r/podcasts, r/standup, r/killtony, etc.) for episode mentions
- Tracks comment velocity on YouTube uploads of episodes
- Scans Twitter/X for clip shares and quote engagement
- Calculates "social heat score" per episode and time-window

### Stage 3: Transcription + Analysis
- Transcribes full episodes using faster-whisper (local) or Whisper API
- Word-level timestamps for precise clip boundaries
- Speaker diarization via Pyannote (who said what)
- Audio energy analysis (laughter detection, crowd reactions, energy spikes)

### Stage 4: Viral Moment Detection
- Composite scoring algorithm combining:
  - Social signal density (mentions/min around a timestamp)
  - Audio energy spikes (laughter, applause, crowd reaction)
  - Transcript "punchline patterns" (setup → delivery → reaction)
  - Speaker overlap / crosstalk intensity
  - Comment keyword clustering (timestamps people reference)
- Outputs ranked list of candidate moments with confidence scores

### Stage 5: Clip Generation
- Extracts 30-second audio segment at detected timestamp
- Generates captions from Whisper word-level timestamps
- Renders 9:16 vertical video with:
  - Animated waveform background
  - Burned-in captions (customizable style)
  - Podcast artwork + episode title overlay
- Exports in both YT Shorts and TikTok specs

## Cron / Scheduling

For weekly automation:
```bash
# Add to crontab: run every Monday at 6 AM
0 6 * * 1 cd /path/to/clipradar && ./venv/bin/python -m backend.pipeline --full
```

## Tech Stack

| Layer | Tech | Purpose |
|-------|------|---------|
| Podcast Data | Spotify API, RSS/XML | Rankings + episode metadata |
| Audio | RSS direct download | Episode MP3 files |
| Transcription | faster-whisper / Whisper API | Speech-to-text with timestamps |
| Diarization | Pyannote | Speaker identification |
| Social Signals | Reddit API, YouTube Data API | Viral proxy detection |
| Audio Analysis | librosa, numpy | Energy/laughter detection |
| Video Render | FFmpeg | Clip generation + captioning |
| Database | PostgreSQL / SQLite | Episode + moment storage |
| Cache | Redis | Ranking + signal caching |
| Frontend | Next.js + React | Dashboard UI |
| Deploy | Railway / Vercel | Hosting + cron |
