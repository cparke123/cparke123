"""Initialize the ClipRadar database."""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from backend.config import settings
from backend.models import init_db
from rich.console import Console

console = Console()


def main():
    console.print("\n[bold cyan]Initializing ClipRadar database...[/bold cyan]\n")

    db_url = settings.database_url
    console.print(f"  Database: {db_url}")

    engine, Session = init_db(db_url)

    console.print("  [green]✓ Tables created[/green]")
    console.print("  [green]✓ Indexes created[/green]")

    # Verify
    session = Session()
    from backend.models import Podcast
    count = session.query(Podcast).count()
    console.print(f"  [green]✓ Podcasts in DB: {count}[/green]")
    session.close()

    console.print("\n[bold green]Database ready.[/bold green]\n")


if __name__ == "__main__":
    main()
